<template>
  <section class="frame-border panel">
    <header class="panel-header">
      <h1 :tabindex="focusable ? '-1' : undefined">{{ title }}</h1>
    </header>
    <div class="panel-body">
      <p>{{ description }}</p>
      <br>
      <p class="lightnote">{{ note }}</p>
    </div>
    
  </section>
</template>

<script setup lang="ts">
defineProps<{
  title: string
  description: string
  note: string
  focusable?: boolean
}>()
</script>
