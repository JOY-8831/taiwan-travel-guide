<script setup>
const state = reactive({
    message: "choose one."
})
</script>

<template>
    {{ state.message }}
</template>

