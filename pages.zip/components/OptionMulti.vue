<template>
  <Button
    :text="label"
    :prefix="selected ? '●' : 'o'"
    type="toggle"
    :selected="selected"
    @click="$emit('toggle', value)"  />
</template>

<script setup lang="ts">
defineProps<{
  label: string
  value: string  // 這是要傳遞回父元件的 ID/值
  selected: boolean
}>()

defineEmits<{
  // 🎯 關鍵修正：定義 toggle 事件會攜帶一個 string 參數 (即 value)
  toggle: [value: string] 
}>()
</script>