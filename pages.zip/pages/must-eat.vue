<!-- pages/must-eat 6.vue -->
<template>
  <div id="must_eat" class="page-layout">
  <ButtonBack />
    <main class="frame">
      <QuestionBox
        title="Places you must go in Taiwan!"
        description="Here are 4 must-visit places in Taiwan. Simply search them on Google Maps to find the nearest locations. We’ve also highlighted some of the most famous ones for you"
        note="✦ Click the cards to view details ✦"      
      />
      
      <section id="see_list">
        <div class="wishcard-grid">
          <WishCard
            v-for="item in mustSeeList"
            :key="item.Code"
            :item="item"
          />
        </div>
      </section>
      
      <ButtonNext
        text="Let's get more specific >"
        type="next"
        @click="navigateTo('/travel-style')"
      />
    </main>
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { useFavorites } from '~/composables/useFavorites' // 確保導入路徑正確
const { getMustSeeList, loadData } = useFavorites()

// 🎯 修正：直接將 Hook 中回傳的 ComputedRef 賦值給 mustSeeList
// getMustSeeList 本身就是響應式的，不需要再次包裝或呼叫
const mustSeeList = computed(() => {
    // 篩選 Code 以 "P-E-" 開頭的項目
    return getMustSeeList.value.filter(item => item.Code.startsWith("P-E-"))
})
onMounted(async () => {
    // 確保數據在組件掛載後載入
    await loadData() 
})
</script>


<style scoped>
/* 讓卡片以 2x2 佈局呈現 */
.wishcard-grid {
  /* 啟用 Grid 佈局 */
  display: grid;
  
  /* 🎯 設置兩欄，每欄佔用均等空間 */
  grid-template-columns: repeat(2, 1fr); 
  
  /* 設置卡片之間的間距 (水平和垂直) */
  gap: 10px; 
  
  /* 確保網格本身在頁面中間（如果頁面寬度大於網格最大寬度） */
  max-width: 900px; /* 根據您的設計調整最大寬度 */
  width: 100%;
  margin: 0 auto;
}

</style>