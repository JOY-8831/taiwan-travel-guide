<template>
  <div id="travel-style" class="page-layout">
    <ButtonBack />
    <main class="frame">
      <QuestionBox
        title="🎒 Choose your travel style!"
        description="You've just landed in a brand-new destination. Select your travelling styles (Multi-select)."
        note=""
      />
      
      <section class="options">
        <OptionMulti
          v-for="option in options"
          :key="option.value"
          :label="option.label"
          :value="option.value"
          :selected="selectedInterests.has(option.value)"
          @toggle="toggleInterest(option.value)"
        />

<section class="options">
    <div v-for="option in options" :key="option.value" style="color: red;">
        {{ option.label }}
    </div>
</section>
        <ButtonNext
          :text="canContinue ? 'Continue' : `Continue (select ${1 - selectedInterests.size} more)`"
          type="next"
          :disabled="!canContinue"
          
          @click="handleContinue" 
        /> 
      </section>
    </main>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
// 💡 假設 navigateTo 函數已經在全域或從某處引入
declare const navigateTo: (path: string) => void;

// 🎯 使用 Set 來儲存多選選項，確保唯一性
const selectedInterests = ref(new Set<string>())

const options = [
  { label: 'City explorer', value: 'City' },
  { label: 'Nature adventurer', value: 'Nature' },
  { label: 'Museums enthusiast', value: 'Museums' },
  { label: 'Relaxation stroller', value: 'Relaxation' }
]

// 🎯 繼續條件: 至少選擇 1 個選項
const canContinue = computed(() => selectedInterests.value.size >= 1)

// 處理選項切換邏輯
const toggleInterest = (value: string) => {
  if (selectedInterests.value.has(value)) {
    selectedInterests.value.delete(value)
  } else {
    selectedInterests.value.add(value)
  }
}

// 🎯 處理繼續流程：儲存資料並導航
const handleContinue = () => {
  if (canContinue.value) {
    // 這裡通常會將 Array.from(selectedInterests.value) 儲存到 Vuex/Pinia 或 Local Storage
    console.log('Selected interests:', Array.from(selectedInterests.value))
    
    // 導航到下一頁
    navigateTo('/points')
  }
}
</script>